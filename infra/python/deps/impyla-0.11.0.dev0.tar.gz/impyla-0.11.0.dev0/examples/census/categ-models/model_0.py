def predict_income(impala_function_context, age, workclass, final_weight, education, education_num, marital_status, occupation, relationship, race, sex, hours_per_week, native_country, income):
    """ Predictor for income from model/

        https://archive.ics.uci.edu/ml/machine-learning-databases/adult/
    """
    return 1729