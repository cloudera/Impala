# content of a module remote1.py

if __name__ == '__channelexec__':
    channel.send('initialization complete')
