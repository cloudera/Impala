Welcome to execnet and elastic distributed computing!

Rapidly deploy tools and code to local or remote Python interpreters.

See doc/ for more info, examples and contact info.

have fun,

holger krekel, holger at merlinux eu

