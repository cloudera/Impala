from fabric.api import task

import debian

@task
def install_package():
    pass
