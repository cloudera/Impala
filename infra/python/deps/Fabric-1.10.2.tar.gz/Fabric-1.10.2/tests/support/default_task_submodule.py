from fabric.api import task

@task(default=True)
def long_task_name():
    pass
