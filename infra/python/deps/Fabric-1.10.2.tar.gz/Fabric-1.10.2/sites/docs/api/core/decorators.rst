==========
Decorators
==========

.. automodule:: fabric.decorators
    :members: hosts, roles, runs_once, serial, parallel, task, with_settings
