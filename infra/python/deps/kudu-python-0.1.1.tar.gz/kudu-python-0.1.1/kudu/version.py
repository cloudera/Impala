
# THIS FILE IS GENERATED FROM SETUP.PY
version = '0.1.1'
isrelease = 'True'