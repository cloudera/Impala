
from __mypkg.othermodule import OtherClass

class SomeClass:
    pass
