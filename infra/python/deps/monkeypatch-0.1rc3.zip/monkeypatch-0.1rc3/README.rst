monkeypatch
===========

Patches module object/class/function.

Package:
  http://pypi.python.org/pypi/monkeypatch
Project:
  https://github.com/iki/monkeypatch
Issues:
  https://github.com/iki/monkeypatch/issues
Updates:
  https://github.com/iki/monkeypatch/commits/master.atom
Sources via `git <http://git-scm.com/>`_:
  ``git clone https://github.com/iki/monkeypatch``
Sources via `hg-git <https://github.com/schacon/hg-git>`_:
  ``hg clone git://github.com/iki/monkeypatch``
