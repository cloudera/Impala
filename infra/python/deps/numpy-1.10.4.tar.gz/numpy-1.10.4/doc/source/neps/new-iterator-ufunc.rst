.. include:: ../../neps/new-iterator-ufunc.rst
